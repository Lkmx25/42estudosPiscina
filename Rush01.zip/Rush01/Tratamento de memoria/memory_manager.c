#include<stdlib.h>

void memory_free(int *array1, int *array2, int *array3)
{
    free(array1);
    free(array2);
    free(array3);
}
void* memory_allocation(int **array, int lenght)
{
    *array = (int*)malloc(sizeof(int) * lenght);
}