void populate_clues(int *lines, int *collums, char *nbrs, int lenght)
{
    int i;
    int k;
    int total;
    total = lenght * 2;
    i = 0;
    k = 0;

    while(nbrs[i])
    {
        if(nbrs[i] >= '1' && nbrs[i] <= (lenght + '0'))
        {
            if(k < total)
            {
                lines[k] = (nbrs[i] - '0');
            }
            else
            {
                collums[k - total] = (nbrs[i] - '0')
            }
            k++;
        }
        i++;
    }
}