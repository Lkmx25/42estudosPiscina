void validate_and_rules(char *nbrs, int **clues_collum, int **clues_lines)
{
    int lenght;
    lenght = str_check(nbrs);

    memory_allocation(clues_collum, lenght);
    memory_allocation(clues_lines, lenght);
    
}