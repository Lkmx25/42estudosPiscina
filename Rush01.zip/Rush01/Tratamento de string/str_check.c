int str_check(char *nbrs)
{
    int i;
    int counter;
    int lenght;
    counter = 0;
    i = 0;
    lenght = (ft_strlen(nbrs) / 4);

    while(nbrs[i])
    {
        if(nbrs[i] >= '1' && nbrs[i] <= (lenght + '0'))
            counter++;
        else if(nbrs[i] != ' ')
            return (1);
        i++;
    }

    if(counter != (lenght * 4))
    {
        return(1);
    }
    return lenght;
}