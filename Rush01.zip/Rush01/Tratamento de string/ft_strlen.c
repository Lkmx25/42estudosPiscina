int ft_strlen(char *nbrs)
{
    int i;
    int counter;
    i = 0;
    counter = 0;

    while(nbrs[i])
    {
        if(nbrs[i] >= '1' && nbrs[i] <= '9')
            counter++;
        i++;
    }
    if(counter < 16 || (counter % 4) != 0)
    {
        return (1);
    }

    return counter;
}